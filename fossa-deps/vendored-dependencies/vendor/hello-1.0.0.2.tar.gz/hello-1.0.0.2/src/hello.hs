module Main (main) where

main = putStrLn "Hello, World!"
