# Revision history for hedgehog-golden

## 1.0.0 -- 2019-11-29

* First version. Released on an unsuspecting world.
